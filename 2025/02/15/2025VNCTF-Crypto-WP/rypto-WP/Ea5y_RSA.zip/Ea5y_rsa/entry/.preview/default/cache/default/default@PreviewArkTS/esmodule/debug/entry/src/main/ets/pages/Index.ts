if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    message?: string;
    flag?: string;
}
import cryptoFramework from "@ohos:security.cryptoFramework";
import buffer from "@ohos:buffer";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('EaSy_rsa', this, "message");
        this.__flag = new ObservedPropertySimplePU('', this, "flag");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.flag !== undefined) {
            this.flag = params.flag;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__flag.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__flag.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    private __flag: ObservedPropertySimplePU<string>;
    get flag() {
        return this.__flag.get();
    }
    set flag(newValue: string) {
        this.__flag.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(12:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#F5F5F5');
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.message);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(13:7)", "entry");
            Text.fontSize(32);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
            Text.margin({ bottom: 40 });
            Text.textShadow({ radius: 2, color: Color.Blue, offsetX: 1, offsetY: 1 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: 'Input the flag here' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(20:7)", "entry");
            TextInput.placeholderColor(Color.Gray);
            TextInput.placeholderFont({ size: 16 });
            TextInput.height(56);
            TextInput.width('80%');
            TextInput.padding(10);
            TextInput.margin({ bottom: 20 });
            TextInput.borderRadius(8);
            TextInput.backgroundColor(Color.White);
            TextInput.onChange((data) => {
                this.flag = data;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('Check Flag', { type: ButtonType.Capsule, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(33:7)", "entry");
            Context.animation({ curve: 'ease-in-out', duration: 200 });
            Button.width('50%');
            Button.height(45);
            Button.backgroundColor('#2196F3');
            Button.margin({ top: 20 });
            Button.opacity(0.9);
            Button.onClick(() => {
                this.check();
            });
            Context.animation(null);
        }, Button);
        Button.pop();
        Column.pop();
    }
    rsaEncryptBySegment(pubKey: cryptoFramework.PubKey, plainText: cryptoFramework.DataBlob) {
        let cipher = cryptoFramework.createCipher('RSA1024|PKCS1');
        cipher.initSync(cryptoFramework.CryptoMode.ENCRYPT_MODE, pubKey, null);
        let plainTextSplitLen = 64;
        let cipherText = new Uint8Array();
        for (let i = 0; i < plainText.data.length; i += plainTextSplitLen) {
            let updateMessage = plainText.data.subarray(i, i + plainTextSplitLen);
            let updateMessageBlob: cryptoFramework.DataBlob = { data: updateMessage };
            // 将原文按64字符进行拆分，循环调用doFinal进行加密，使用1024bit密钥时，每次加密生成128字节长度的密文。
            let updateOutput = cipher.doFinalSync(updateMessageBlob);
            let mergeText = new Uint8Array(cipherText.length + updateOutput.data.length);
            mergeText.set(cipherText);
            mergeText.set(updateOutput.data, cipherText.length);
            cipherText = mergeText;
        }
        let cipherBlob: cryptoFramework.DataBlob = { data: cipherText };
        return cipherBlob;
    }
    rsaDecryptBySegment(priKey: cryptoFramework.PriKey, cipherText: cryptoFramework.DataBlob) {
        let decoder = cryptoFramework.createCipher('RSA1024|PKCS1');
        decoder.initSync(cryptoFramework.CryptoMode.DECRYPT_MODE, priKey, null);
        let cipherTextSplitLen = 128; // RSA密钥每次加密生成的密文字节长度计算方式：密钥位数/8。
        let decryptText = new Uint8Array();
        for (let i = 0; i < cipherText.data.length; i += cipherTextSplitLen) {
            let updateMessage = cipherText.data.subarray(i, i + cipherTextSplitLen);
            let updateMessageBlob: cryptoFramework.DataBlob = { data: updateMessage };
            // 将密文按128字节进行拆分解密，得到原文后进行拼接。
            let updateOutput = decoder.doFinalSync(updateMessageBlob);
            let mergeText = new Uint8Array(decryptText.length + updateOutput.data.length);
            mergeText.set(decryptText);
            mergeText.set(updateOutput.data, decryptText.length);
            decryptText = mergeText;
        }
        let decryptBlob: cryptoFramework.DataBlob = { data: decryptText };
        return decryptBlob;
    }
    check() {
        console.log(this.flag);
        let keyGenerator = cryptoFramework.createAsyKeyGenerator('RSA1024');
        let keyPair = keyGenerator.generateKeyPairSync();
        let plainText: cryptoFramework.DataBlob = { data: new Uint8Array(buffer.from(this.flag, 'utf-8').buffer) };
        let encryptText = this.rsaEncryptBySegment(keyPair.pubKey, plainText);
        let decryptText = this.rsaDecryptBySegment(keyPair.priKey, encryptText);
        if (plainText.data.toString() === decryptText.data.toString()) {
            console.info('decrypt ok');
            console.info('decrypt plainText: ' + buffer.from(decryptText.data).toString('utf-8'));
        }
        else {
            console.error('decrypt failed');
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.ea5y_rsa", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
