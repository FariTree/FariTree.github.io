#!/usr/bin/env python    
from unicorn import *
from unicorn.x86_const import *
from capstone import *
from capstone.x86_const import *
import os
import sys
import random
from Crypto.Util.number import *

flag = os.getenv('FLAG','test{This_is_a_test_flag_connect_to_get_true_flag}').encode()


CODE_COUNT = 0
TARGET_COUNT = 0
# memory address where emulation starts
CODE_ADDRESS    = 0x110000
DATA_ADDRESS    = 0x220000
KEY_ADDRESS     = 0x440000
STACK_ADDRESS   = 0x880000
CODE = b''
with open("/app/prog_aes4","rb") as f:
    CODE = f.read()


ENTRY_POINT = CODE_ADDRESS + 0x9E5
ENTRY_POINT_END = CODE_ADDRESS + 0xF6F


def flipBit(uc:Uc,reg_name:str):
    randBit = random.randint(0,7) #not 0,63
    reg_num = eval("UC_X86_REG_" + reg_name.upper())
    reg_value = uc.reg_read(reg_num)
    reg_value ^= 1 << randBit
    uc.reg_write(reg_num,reg_value)

def shock(uc:Uc):
    rip = uc.reg_read(UC_X86_REG_RIP)
    code = uc.mem_read(rip,16)
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    md.detail = True
    dis = None
    for d in md.disasm(code, 0):
        dis = d
        break
    for reg_list in dis.regs_access():
        for reg in reg_list:
            flipBit(uc,md.reg_name(reg))


def hook_code(uc:Uc, address, size, user_data):
    global CODE_COUNT
    if(CODE_COUNT >= 2000000):
        print("   [⏰] Time Limit Exceed")
        uc.emu_stop()
    if(CODE_COUNT == TARGET_COUNT):
        print("   [⚡] Shock!")
        shock(uc)
    CODE_COUNT += 1

def run(data,key,target):
    print("   [🔒] to enc: ",data.hex())
    try:
        global CODE_COUNT
        global TARGET_COUNT
        CODE_COUNT = 0
        TARGET_COUNT = target
        # Initialize emulator 
        mu = Uc(UC_ARCH_X86, UC_MODE_64)

        # map memory
        mu.mem_map(CODE_ADDRESS, 2 * 0x1000) # Code
        mu.mem_map(DATA_ADDRESS, 1 * 0x1000) # DATA
        mu.mem_map(KEY_ADDRESS, 1 * 0x1000) # KEY
        mu.mem_map(STACK_ADDRESS, 2 * 0x1000) # STACK
        # write machine code to be emulated to memory

        mu.mem_write(CODE_ADDRESS, CODE)
        mu.mem_write(KEY_ADDRESS, key)
        mu.mem_write(DATA_ADDRESS, data)

        # initialize machine registers
        mu.reg_write(UC_X86_REG_RIP, ENTRY_POINT)
        mu.reg_write(UC_X86_REG_RDI, DATA_ADDRESS)
        mu.reg_write(UC_X86_REG_RSI, 16)
        mu.reg_write(UC_X86_REG_RDX, KEY_ADDRESS)
        mu.reg_write(UC_X86_REG_RSP, STACK_ADDRESS + 0x1000)

        # tracing all instructions with customized callback
        mu.hook_add(UC_HOOK_CODE, hook_code)

        # emulate machine code in infinite time
        mu.emu_start(ENTRY_POINT, ENTRY_POINT_END)

        result = mu.mem_read(DATA_ADDRESS, 16)
        print("   [▶️] Result: ",result.hex())

    except UcError as e:
        print("   [💥] BOOM: %s" % e) # https://www.bilibili.com/video/BV1ynKQzHEED
    return


AES_KEY = os.urandom(16)
AES_PTS = b''
Shocktime = 9999999

if __name__ == '__main__':
    count=0
    while count < 1:
        count += 1
        print("Round %d / 1"%(count))
        print("Input your data: in hex(max 16 bytes)")
        try:
            AES_PTS = bytes.fromhex(input())[0:16]
        except:
            print("wrong input!")
            sys.exit(1)
        Shocktime=input("time to shock: ")
        try:
            Shocktime=int(Shocktime)
        except:
            print("wrong input!")
            sys.exit(1)
        run(AES_PTS,AES_KEY,Shocktime)    
        guesskey=input("now give me your guess key: ")
        if guesskey[0] == "n":
            continue
        try:
            guesskey=bytes.fromhex(guesskey)[0:16]
        except:
            print("wrong input!")
            sys.exit(1)
        if guesskey==AES_KEY:
            print("FLAG:",flag)
            sys.exit(0)
        else:
            print("No Second Chance")
            sys.exit(1)
