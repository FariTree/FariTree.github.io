from Crypto.Util.number import *
from Crypto.Cipher import AES
from hashlib import sha256
import socketserver
import signal
import os
import string
import random
from Crypto.PublicKey import RSA
from Crypto.Util.number import getPrime,getStrongPrime
from Crypto.Random import get_random_bytes
from sample import sample_clock,sample_serialdata

import numpy as np
from scipy.io import savemat,loadmat
from random import randint
FLAG=os.getenv("FLAG","FAKE{"+6*"0123456789").encode()

class Task(socketserver.BaseRequestHandler):
    def _recvall(self):
        BUFF_SIZE = 1024
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data.strip()

    def send(self, msg, newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def recv(self, prompt=b'> '):
        self.send(prompt, newline=False)
        return self._recvall()

    def handle(self):
        '''
        case of clock
        generate_clock_signal_with_slack(
        sampling_rate=500e6,
        signal_frequency=4e6,
        num_cycles=100,
        output_file="clock_signal.mat"
        )
        '''
        
        count=70
        l=64
        data=[random.randint(0,1) for i in range(l)]
        print(data)
        sample_serialdata(
            sampling_rate=500e6,
            signal_frequency=4e6,
            data=data,
            output_file="serial_data.mat"
        )
        samples = np.array(loadmat("serial_data.mat")["data"][0])
        
        while count>=0:
            self.send(b"function\n1.query\n2.get flag")
            s=self.recv()
            try:
                s=int(s)
            except:
                exit()
            if s==1:
                self.send(b"ur sample position?")
                s=self.recv()
                try:
                    s=int(s)
                except:
                    exit()
                if 0<=s<len(samples):
                    self.send(str(samples[s]).encode())
                else:
                    self.send(b"wrong position\n")
                    
            elif s==2:
               for i in range(l):
                   self.send(b"ur guess data[%d]?"%i)
                   s=self.recv()
                   try:
                       s=int(s)
                   except:
                       exit()
                   if s!=data[i]:
                       self.send(b"wrong")
                       return
               self.send(b"congratulations! your part flag is:")        
               self.send(FLAG[:count]) 
            count=count-1
           
                       
               
                         
            
                    
            



class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


class ForkedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 9999
    print("HOST:POST " + HOST+":" + str(PORT))
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()
