import os
import json
import requests
from flask import Flask, render_template, request, jsonify
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

app = Flask(__name__)


def get_key():
    try:
        with open("key", "r") as f:
            key_hex = f.read().strip()
            return bytes.fromhex(key_hex)
    except FileNotFoundError:
        print("Error: 'key' file not found.")
        exit(1)
    except ValueError:
        print("Error: Invalid hex string in 'key' file.")
        exit(1)


KEY = get_key()

SERVER_URL = os.getenv("SERVER_URL", "http://localhost:5000/")


def encrypt_data(data):
    nonce = get_random_bytes(12)
    cipher = AES.new(KEY, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(data)
    return nonce, ciphertext, tag


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/send", methods=["POST"])
def send_to_server():
    username = request.form.get("username")

    if not username:
        return jsonify({"error": "Username is required"}), 400
    if not 2 <= len(username) <= 10:
        return jsonify({"error": "Username length must be between 2 and 10"}), 400
    if not username.isascii():
        return jsonify({"error": "Username must contain only ASCII characters"}), 400

    try:
        payload = {"route": "/chat", "data": username}

        payload_bytes = json.dumps(payload).encode("utf-8")
        nonce, ciphertext, tag = encrypt_data(payload_bytes)

        request_data = {
            "nonce": nonce.hex(),
            "data": (ciphertext + tag).hex(),
            "username": username,
        }

        response = requests.post(SERVER_URL + "/encrypted", json=request_data)

        if response.status_code == 200:
            return jsonify(response.json())
        else:
            return (
                jsonify(
                    {
                        "error": f"Server responded with status code {response.status_code}",
                        "detail": response.text,
                    }
                ),
                response.status_code,
            )

    except requests.exceptions.RequestException as e:
        return (
            jsonify({"error": "Failed to connect to the server", "detail": str(e)}),
            500,
        )
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "detail": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
