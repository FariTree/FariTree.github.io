#!/bin/bash
function cleanup {
  kill "$SERVER_PID"
  exit 0
}
trap cleanup SIGINT SIGTERM

python server.py &
SERVER_PID=$!

sleep 2

echo "Starting client on port 5001..."
export SERVER_URL="http://localhost:5000"
python client.py

wait "$SERVER_PID"