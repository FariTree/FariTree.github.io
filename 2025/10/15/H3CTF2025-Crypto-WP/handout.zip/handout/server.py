import os
import json
from flask import Flask, request, jsonify
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

app = Flask(__name__)

def get_key():
    try:
        with open("key", "r") as f:
            key_hex = f.read().strip()
            print("For Debug:", key_hex)
            return bytes.fromhex(key_hex)
    except FileNotFoundError:
        print("Error: 'key' file not found.")
        exit(1)
    except ValueError:
        print("Error: Invalid hex string in 'key' file.")
        exit(1)

KEY = get_key()

GREETINGS = [
    "Hello World!",
    "BV1iXXhYpEcw!",
    "Capture The Flag!",
    "Welcome To H^3CTF!",
    "Miss Suzuran is our light",
    "You've found the secret of 42",
]

def encrypt_data(nonce, data):
    cipher = AES.new(KEY, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(data)
    return nonce, ciphertext, tag

def decrypt_data(nonce, ciphertext, tag):
    try:
        cipher = AES.new(KEY, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        return plaintext
    except (ValueError, KeyError) as e:
        print(f"Decryption error: {e}")
        return None

@app.route("/encrypted", methods=["POST"])
def handle_encrypted_data():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    required_fields = ["username", "nonce", "data"]
    if not all(field in request.json for field in required_fields):
        return jsonify({"error": "Missing required fields"}), 400

    try:
        nonce = bytes.fromhex(request.json.get("nonce"))
        encrypted_data_hex = request.json.get("data")
        username = request.json.get("username").encode('utf-8')
        
        ciphertext_with_tag = bytes.fromhex(encrypted_data_hex)
        ciphertext = ciphertext_with_tag[:-16]
        tag = ciphertext_with_tag[-16:]

        
        decrypted_json_bytes = decrypt_data(nonce, ciphertext, tag)
        if decrypted_json_bytes is None:
            return jsonify({"error": "Decryption failed"}), 400
        print("Point1", decrypted_json_bytes.decode('utf-8'))

        decrypted_json = json.loads(decrypted_json_bytes.decode('utf-8'))
        print("Point2")
        
        route = decrypted_json.get("route")
        
        response_data = {}
        
        if route == "/getflag":
            flag = os.getenv("FLAG", "flag{fake_fake_fake_flag}")
            response_data = {"result": flag}
        elif route == "/chat":
            import random
            response_data = {"result": random.choice(GREETINGS)}
        else:
            return jsonify({"error": "Invalid route"}), 400
        
        nonce = username + get_random_bytes(12 - len(username))
        response_json_bytes = json.dumps(response_data).encode('utf-8')
        print(response_json_bytes)
        nonce_out, ciphertext_out, tag_out = encrypt_data(nonce, response_json_bytes)
        
        return jsonify({
            "nonce": nonce_out.hex(),
            "data": (ciphertext_out + tag_out).hex()
        })
        
    except (ValueError, json.JSONDecodeError) as e:
        return jsonify({"error": f"Invalid data format: {e}"}), 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)